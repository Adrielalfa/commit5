@extends('layoutss.app')

@section('title, 'cobaaaaaa')

@@section('content')
    urutan ke - {{ $ke }}
@endsection